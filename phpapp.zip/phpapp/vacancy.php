<?php
echo "hosircha bu sahifa bizda qo'shilmagan";
?>